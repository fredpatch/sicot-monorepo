/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{ts,tsx}'],
  theme: {
    extend: {
      // ── Charte graphique ANAC ──────────────────────────────────────────
      colors: {
        anac: {
          // Bleu institutionnel ANAC (extrait du logo et des documents)
          navy:    '#1B2A5E',  // Bleu marine principal
          blue:    '#2B4DAE',  // Bleu intermédiaire
          sky:     '#4A90D9',  // Bleu clair accent
          // Couleurs complémentaires
          white:   '#FFFFFF',
          gray:    '#F4F6FA',
          border:  '#D1D9E6',
          text:    '#1A2340',
          muted:   '#6B7A99',
          // Statuts
          success: '#16A34A',
          warning: '#D97706',
          danger:  '#DC2626',
          info:    '#0891B2',
        },
      },
      fontFamily: {
        // Candara est la police ANAC — on la déclare et on tombera sur
        // la stack système si elle n'est pas installée côté client
        sans: ['Candara', 'Calibri', 'Trebuchet MS', 'ui-sans-serif', 'system-ui'],
      },
      fontSize: {
        // Taille ANAC : 12 ou 13px
        base: ['13px', { lineHeight: '1.5' }],
        sm:   ['12px', { lineHeight: '1.5' }],
      },
    },
  },
  plugins: [],
};
